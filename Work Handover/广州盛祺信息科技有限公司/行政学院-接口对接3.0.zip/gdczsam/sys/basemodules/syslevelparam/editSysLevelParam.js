var loginBackgroundPicPath = "";//登录背景图片路径
var loginKuangPicPath = "";//登录框图片路径
var bottomPicPath = "";//底部栏图片路径
var mainLogoPicPath = "";//主页logo图片路径

$(function(){
    loadDockers();
	//取得数据
	getdatas();
	//事件绑定
	eventBlind();
	//检查应用是否已注册
	checkSCReg();
	//初始化颜色选择器
	initColorClick();
	//初始化添加底部栏信息按钮绑定事件
	bindAddBtnEvent();
});	
//事件绑定
function eventBlind(){
	$("#getSI").click(getServerInfoByType);
	$("#regSN").click(regSerialNumber);
	enterRegNumberEvent();
	
	var index;//layer的tip弹窗指针
	//繁忙开始时间
	$('#busytimestar').bind('input propertychange', function() {
		if($('#busytimestar').val()>23){
			 top.layer.alert('请填写0-23时',{closeBtn :0,icon:5});
			$('#busytimestar').val(""); 
		}
	});
	//繁忙结束时间
	$('#busytimeend').bind('input propertychange', function() {
		if($('#busytimeend').val()>23){
			 top.layer.alert('请填写0-23时',{closeBtn :0,icon:5});
			 $('#busytimeend').val("");
		}		
	}); 
	
	//文件清理周期
	$("#clearcycle").focus(function(){
		if(index!=undefined)layer.close(index);
		index=layer.tips('当为0时,不清除文件数据','#clearcycle', {tips:3});
	}).blur(function(){if(index!=undefined)layer.close(index);});
	//繁忙时间段

	$("#busytimestar,#busytimeend").focus(function(){
		if(index!=undefined)layer.close(index);
		index=layer.tips('24时制格式，填写0~23。<br/>'+
						 '格式如：9-18,含义为早上9点到18点均为繁忙时段。大数据任务将在19点后开始处理。<br/>'+
		                 '如当繁忙时段为0-0时，视为全天空闲。任何导出任务立刻执行。',$(this), {tips:3});
	}).blur(function(){if(index!=undefined)layer.close(index);});
	//附件保存路径
	$("#appendSavePath").focus(function(){
		if(index!=undefined)layer.close(index);
		index=layer.tips('两种配置方式，按文件存放于本服务器还是局域网内其他服务器区分如下：<br/>'+
						 '1、本地路径，如：D:/file/download(windows)或/user/append(linux)<br/>'+
						 '2、局域网共享文件夹，格式为ip地址+\';\'+共享文件夹名称+\';\'+用户名+\';\'+密码。格式如：127.0.0.1;download;Guest;123。注意：局域网密码就不要带;的了，方便系统识别。<br/>'+
						 '若没有设置，则默认存放于系统/gdczsam/appendfile和/gdczsam/exportfile目录下。若更改附件路径，需将原来的附件文件夹移动到新路径下',
						 $(this), {tips:3,time :5000,area: '500px'});
	});
	// 触发提交事件 
	$("#submit").click(function(){
		// 验证通过则返回为true
		if(validateData())
		if($("#ff").form("validate")){
			ajaxSave(getdataPackage()); 
		}
	});
	// 触发提交事件
	$("#refreshOrgCacheTree").click(refreshOrgCacheTree);
	$("#reloadProgramVersion").click(refreshProgramVersion);
	$("#refreshBarCodeCacheTree").click(refreshBarCodeCacheTree);
    $("#reloadDockerAchieveProperties").click(reloadDockerAchieveProperties);

    //重置页面
	$("#reset").click(resetRefreshPage);
}

//重置刷新页面
function resetRefreshPage(){
	top.layer.open({
		title:'信息',
		closeBtn :0,
		icon: 3,
		btn:['确定', '取消'],
		content:'确定放弃保存并刷新当前页面吗',
		yes: function(index){
			top.layer.close(index);
			location.reload();
	    }
	});
}

//异步请求保存数据
function ajaxSave(obj){
	top.layer.open({
		title:'信息',
		closeBtn :0,
		icon: 3,
		area:[250,150],
		btn:['确定', '取消'],
		content:'确定要进行保存操作吗',
		yes: function(index){
				//一般设定yes回调，必须进行手工关闭

				top.layer.close(index);
				//开启遮挡层
				$('body').addLoading({msg:'正在保存数据，请等待...'});
				
			  	Ajax.service(
					'SysLevelParamBO',
					'saveSysLevelParam', 
				    [obj],
				    function(data){
						//关闭遮挡层
						$("body").removeLoading();
						if(data != null && data.length>0){
							top.layer.alert(data,{closeBtn :0,icon:5}); 
						}else{
							top.layer.alert("保存成功",{closeBtn :0,icon:1}); 
						}		
				    }
				); 		  	
	    }
	});
}
//数据封装 
var dataPackage={};
function getdataPackage(){	
	var inputs=$("#ff input");
	if(inputs.length>0){
		for(var i=0;i<inputs.length;i++){			
			if(inputs.eq(i).attr("type")=="text"){
				if(inputs.eq(i).hasClass('numberbox-f') && inputs.eq(i).attr('numberboxname')){
					  var num=inputs.eq(i).numberbox('getValue');
					  if(num.length==0)num=0;
							dataPackage[inputs.eq(i).attr('numberboxname')]=num;
				}else if(inputs.eq(i).attr('name')!=undefined&&inputs.eq(i).attr('name')!=""){
					if(inputs[i].value==inputs[i].getAttribute('placeholder')){
						dataPackage[inputs.eq(i).attr('name')]='';							
					}else{
						dataPackage[inputs.eq(i).attr('name')]=inputs.eq(i).val().trim();
					}
					
				}
			}			
		}
	}
	dataPackage.showaccountform = $("#showaccountform").combobox("getValue");
	dataPackage.showAssetAcceptance = $("#showAssetAcceptance").combobox("getValue");
	dataPackage.isPrintTwoBarCode = $("#isPrintTwoBarCode").combobox("getValue");
	dataPackage.showMsg = $("#showMsg").combobox("getValue");
	dataPackage.canSelectSummaryNode = $("#canSelectSummaryNode").combobox("getValue");
	dataPackage.generalChangeSet = $("#generalChangeSet").combobox("getValue");
	dataPackage.logClientInfo = $("#logClientInfo").combobox("getValue");
	if(loginBackgroundPicPath!=""){
		dataPackage.loginBackgroundPicPath = loginBackgroundPicPath;
	}
	if(loginKuangPicPath!=""){
		dataPackage.loginKuangPicPath = loginKuangPicPath;
	}
	//if(bottomPicPath!=""){
		dataPackage.bottomPicPath = bottomPicPath;
	//}
	if(mainLogoPicPath!=""){
		dataPackage.mainLogoPicPath = mainLogoPicPath;
	}
	dataPackage.bottomLeftInfo = getBottomInfo($("#customerInfoDiv"));
	dataPackage.bottomRightInfo = getBottomInfo($("#companyInfoDiv"));
	
	//验证码策略搜集
	dataPackage.verifyCodePolicy = $("input[name='verifyCodePolicy']:checked").val();
	if(!dataPackage.verifyCodePolicy){
		dataPackage.verifyCodePolicy = 2;
	}
	dataPackage.deprStatisticalTermsSet = $("#deprStatisticalTermsSet").combobox("getValue");
	
	return dataPackage;
}

//封装底部栏左侧客户信息或右侧公司信息
function getBottomInfo(infoDivObj){
	var infoDivs = infoDivObj.find(".single_info_div");
	var infoArray = new Array();
	for(var i=0;i<infoDivs.length;i++){
		var obj = new Object();
		if($(infoDivs[i]).find("textarea").length>0){
			var text = $(infoDivs[i]).find("textarea").val();
			if($.trim(text).length<1){
				continue;
			}
			text = text.replace(/\r\n/g,"##");  
			text = text.replace(/\n/g,"##");
			obj.text = text;
			infoArray.push(obj); 
		}else if($(infoDivs[i]).find("img").length>0){
			var imgName = $(infoDivs[i]).find("img").attr("name-data");
			obj.picpath = imgName;
			infoArray.push(obj); 
		}
	}
	return JSON.stringify(infoArray);
}

//获取数据
function getdatas(){
  	Ajax.service(
			'SysLevelParamBO',
			'getSysLevelParam', 
		    [],
		    function(data){
				dataPackage=data;
				dataFill(data);
		    }
		);        
}
//数据填充 
function dataFill(objdata){
	var  seachid;
	// 开始遍历 
	for(var p in objdata){
		if(p=='welLoginBackColor'||p=='loginBtnBackColor'||p=='loginBackgroundColor') {
			$('#'+p).val(objdata[p]);	
			$('#'+p).css('border-color','#'+objdata[p]);
			$('#'+p).colpickSetColor(objdata[p]);
			if(p=='welLoginBackColor') {
				$('#id_div_mainlogo').css('background-color','#'+objdata[p]);
			}
		}else if(p=="loginBackgroundPicPath"||p=="loginKuangPicPath"||p=="bottomPicPath"||p=="mainLogoPicPath"){
			$('#'+p).attr("src",top.contextPath+"/core/style/commonimages/"+objdata[p]);
			if(p=="bottomPicPath"){
				bottomPicPath = objdata[p];
			}
		}else if(p=="bottomLeftInfo"){
			initCustomerInfo(objdata[p]);
		}else if(p=="bottomRightInfo"){
			initCompanyInfo(objdata[p]);
		}else if(p=="showaccountform" || p=="showAssetAcceptance" || p=="isPrintTwoBarCode" || p=="showMsg" || p=="canSelectSummaryNode" || p=="logClientInfo"|| p=="generalChangeSet"|| p=="deprStatisticalTermsSet"){
			if(objdata[p] != null)
			$('#'+ p).combobox('select',objdata[p]);
		}else if(p=="verifyCodePolicy"){
			initVerifyCodePolicy(objdata[p]);
		}else if($('#'+p)[0]&&$('#'+p).hasClass('numberbox-f')){
			$('#'+p).numberbox('setValue',objdata[p]);
		}else if($("input[name='"+p+"']:eq(0)").length!=0){
		 	if(objdata[p]!=null)
				$("input[name='"+p+"']")[0].value=objdata[p];
		} 
	}
}
//校验格式
function validateData(){
	if(parseInt($('#busytimestar').val())>parseInt($('#busytimeend').val())){
		 top.layer.alert('开始时间不能大于结束时间',{closeBtn :0,icon:5});
		 return false;
	}
	
	// 文件根字符串解析正则表达式

	var WIN_FILE_REGEX = /^\w:(\/\w+)+\/??$/;// 本地文件(目前只有windows系统)
	var LINUX_FILE_REGEX = /^(\/\w+)+\/??$/;// 本地文件(目前只有windows系统)
	var SMBFILE_REGEX = /^(\d{1,3}\.){3}\d{1,3}(;[\d\D]*){3}$/;// 共享文件
	//校验附件保存路径
	var appendSavePath = $("#appendSavePath").val();
	if(appendSavePath.length>0&&appendSavePath!=$("#appendSavePath").attr('placeholder'))
	if(!(WIN_FILE_REGEX.test(appendSavePath)||SMBFILE_REGEX.test(appendSavePath)||LINUX_FILE_REGEX.test(appendSavePath))){
		 top.layer.alert('请正确填写附件配置路径格式',{closeBtn :0,icon:5});
		 return false;
	}	
	return true;
}

/*根据注册类型生成服务器主机信息*/
function getServerInfoByType(){
	top.layer.open({
		type: 1,
		title:'请选择注册情况',
		area:['290px','180px'],
		shift:1,
		closeBtn:2,
		content:'<div style="padding:20px 10px;font-size:14px;">'+
				'<div style="margin-bottom:10px;">只用于本地测试的请选择[<a id="test_a" href="javascript:void(0);">测试</a>]</div>'+
				'<div>用于正式服务器或将用于正式服务器的请选择[<a id="formal_a" href="javascript:void(0);">正式</a>]</div>'+
				'</div>',
		success: function(layero, index){
			$(layero).find("#test_a").click(function(){
				top.layer.close(index);
				getServerInfo(1);
			});
			$(layero).find("#formal_a").click(function(){
				top.layer.close(index);
				getServerInfo(2);
			});
		}
	});
}
/**获取服务器主机信息*/
function getServerInfo(type){
	$('body').addLoading({msg:'正在获取服务器主机信息，请等待...'});
	Ajax.service(
		'SysLevelParamBO',
		'getServerInfo',
		[],
		function(data){
			$('body').removeLoading();
			var scStr = "待分配";
			if(dataPackage.serverCode!=undefined && dataPackage.serverCode!=null && dataPackage.serverCode.length>0){
				scStr = dataPackage.serverCode;
			}
			top.layer.open({
				type: 1,
				title:'服务器主机信息',
				area:['290px','200px'],
				shift:1,
				closeBtn:2,
				content:'<table style="padding-top: 20px;padding-left: 20px;">'
					+'<tr><td align="right">操作系统名称：</td><td style="font-size: 14px;">'+data.osVendorName+'</td></tr>'
					+'<tr><td align="right">IP地址：</td><td style="font-size: 14px;">'+data.ip+'</td></tr>'
					+'<tr><td align="right">MAC地址：</td><td style="font-size: 14px;">'+data.mac+'</td></tr>'
					+'<tr><td align="right">服务器号：</td><td style="font-size: 14px;">'+(scStr.length<4?(type==1?'0000':scStr):scStr)  +'</td></tr>'
					+'</table>'
			});
	    }
	);
}

//初始化序列号输入框事件
function enterRegNumberEvent(){
	$('#scReg2 .sn-input').bind({
		'input propertychange' : function() {
		    var val = $.trim($(this).val());
		    var regNumArr;
		    if(val.length>=42){
		    	regNumArr = val.split("-");
		    }
		    if(regNumArr!=undefined && regNumArr.length>=8){
		    	for(var i=0;i<=8;i++){
		    		$("#sn"+i).val(regNumArr[i]);
		    	}
		    }
		},
		'keyup' : function(){
			var $this = $(this);
			var index = parseInt($this.attr("id").substring(2));
			var val = $this.val();
			var maxLen = index==0?2:4;
			if(index<=8 && val.length>=maxLen){
				$this.blur();
				if(val.length>maxLen){
					$this.val(val.substring(0,maxLen));
				}
				if(index!=8){
					var nextIndex = index+1;
					$("#sn"+nextIndex).focus();
				}
			}
		}
	});
} 

var clicked = false;
/**注册输入的序列号*/
function regSerialNumber(){
	if(clicked){
		top.layer.alert('请勿重复点击',{closeBtn :0,icon:5});
		return;
	}
	clicked = true;
	var sn = "";
	var jqObj = null;
	var snVal = null;
	for(var i=0;i<9;i++){
		jqObj = $("#sn"+i);
		snVal = jqObj.val();
		if(i==0){
			if(snVal.length < 2){
				top.layer.alert('请输入完整序列号',{closeBtn :0,icon:5},function(index){
					top.layer.close(index);
					jqObj.focus();
				});
				clicked = false;
				return;
			}
		}else{
			if(snVal.length < 4){
				top.layer.alert('请输入完整序列号',{closeBtn :0,icon:5},function(index){
					top.layer.close(index);
					jqObj.focus();
				});
				clicked = false;
				return;
			}
		}
		sn += "-" + snVal;
	}
	sn = sn.substring(1);
	$('body').addLoading({msg:'正在注册序列号，将需要花费您一小段时间，请稍后...'});
	Ajax.service(
		'SysLevelParamBO',
		'regSerialNumber',
		[sn],
		function(data){
			clicked = false;
			$('body').removeLoading();
			if(data == null){
				top.layer.alert("注册成功，请逐个检查下方的配置，仔细阅读每个配置的说明，有些配置非常重要，务必配置无误",{closeBtn :0,icon:6},function(index){
					top.layer.close(index);
					window.location.reload();
				});
			}else{
				top.layer.alert(data,{closeBtn :0,icon:5});
			}
	    },
	    function(){
	    	clicked = false;
	    	$('body').removeLoading();
	    	top.layer.alert('注册失败，请联系管理员',{closeBtn :2,icon:5});
	    }
	); 
}

function checkSCReg(){
	Ajax.service(
		'SysLevelParamBO',
		'isSysRegistered',
		[],
		function(data){
			if(data == "false"){
				$("#scReg1").show();
				$("#scReg2").show();
			}
	    }
	);
}

//初始化底部栏左侧客户信息
function initCustomerInfo(customerInfo){
	if(customerInfo==""||customerInfo==null)return;
	//customerInfo是一个数组字符串，这里转为数组
	customerInfo = eval(customerInfo);
	for(var i=0;i<customerInfo.length;i++){
		var obj = customerInfo[i];
		if(obj.hasOwnProperty('text')){
			var text = obj.text;
			text = text.replace(/##/g,'\n'); 
			addCustomerText(text);
		}else if(obj.hasOwnProperty('picpath')){
			var fileName = obj.picpath;
			var path = top.contextPath+"/core/style/commonimages/"+fileName;
			var html = '<div class="single_info_div"><img src="'+path+'" name-data="'+fileName+'"/></div>';
			if($("#empty_customer_info").length > 0){
				$("#empty_customer_info").before(html);
			}else{
				html += '<div class="empty_btn_div" id="empty_customer_info"><button onclick="emptyCustomerInfo()" class="btn-basic btn-delete"><i class="btn-icon delete-icon"></i>清空</button></div>';
				$("#customerInfoDiv").append(html);
			}
		}
	}
}
//初始化底部栏右侧公司信息
function initCompanyInfo(companyInfo){
	if(companyInfo==""||companyInfo==null)return;
	//companyInfo是一个数组字符串，这里转为数组
	companyInfo = eval(companyInfo);
	for(var i=0;i<companyInfo.length;i++){
		var obj = companyInfo[i];
		if(obj.hasOwnProperty('text')){
			var text = obj.text;
			text = text.replace(/##/g,'\n'); 
			addCompanyText(text);
		}else if(obj.hasOwnProperty('picpath')){
			var fileName = obj.picpath;
			var path = top.contextPath+"/core/style/commonimages/"+fileName;
			var html = '<div class="single_info_div"><img src="'+path+'" name-data="'+fileName+'"/></div>';
			if($("#empty_company_info").length > 0){
				$("#empty_company_info").before(html);
			}else{
				html += '<div class="empty_btn_div" id="empty_company_info"><button onclick="emptyCompanyInfo()" class="btn-basic btn-delete"><i class="btn-icon delete-icon"></i>清空</button></div>';
				$("#companyInfoDiv").append(html);
			}
		}
	}
}
//初始化颜色选择器
function initColorClick() {
	$('#welLoginBackColor').colpick({
		llayout:'full',
		submit:0,
		onChange:function(hsb,hex,rgb,el,bySetColor) {
			$(el).css('border-color','#'+hex);
			if(!bySetColor) $(el).val(hex);
		}
	}).keyup(function(){
		$(this).colpickSetColor(this.value);
	});
	
	$('#loginBtnBackColor').colpick({
		llayout:'full',
		submit:0,
		onChange:function(hsb,hex,rgb,el,bySetColor) {
			$(el).css('border-color','#'+hex);
			if(!bySetColor) $(el).val(hex);
		}
	}).keyup(function(){
		$(this).colpickSetColor(this.value);
	});
	
	$('#loginBackgroundColor').colpick({
		llayout:'full',
		submit:0,
		onChange:function(hsb,hex,rgb,el,bySetColor) {
			$(el).css('border-color','#'+hex);
			if(!bySetColor) $(el).val(hex);
		}
	}).keyup(function(){
		$(this).colpickSetColor(this.value);
	});
}

/**初始化验证码策略*/
function initVerifyCodePolicy(vcPolicy){
	vcPolicy = (vcPolicy==0)?"2":vcPolicy;//默认每次登录要验证码
	$("#id_verifyCodePolicy"+vcPolicy).click();
}

//修改登录背景图片
function editLoginBgPic(){
	openUploadPicWindow("changeLoginBg");
}
//修改登录框背景图片
function editLoginKuangPic(){
	openUploadPicWindow("changeLoginKuang");
}
//修改底部栏背景图片
function editBottomPic(){
	openUploadPicWindow("changeBottomPic");
}
//修改主页logo
function editMainLogoPic(){
	openUploadPicWindow("changeLogoPic");
}
//打开上传图片窗口
function openUploadPicWindow(busiType){
	var param = 'openwindowname=' + window.name+'&busiType='+busiType+'&cID=SysLevelParamBO&mID=uploadPic&path=fuck1&path2=fuck2';
	top.layer.open({type:2, title:"\u56fe\u7247\u4e0a\u4f20", area:["690px", "500px"], shift:1, closeBtn:2, content:contextPath + "/core/componentmodule/picture/editSpecialPicUpload.jsp?"+param});
}
//图片上传回调函数
function updatePicData(busiType,successUploadInfo) {
	var data = JSON.stringify(successUploadInfo);
	var dataArr = eval(data);
	var dataLength = dataArr.length;
	if(dataLength>0){
		var fileName = dataArr[dataLength-1].fileID+"."+dataArr[dataLength-1].compressFileID;
		var path = top.contextPath+"/core/style/commonimages/"+fileName;
		if(busiType=="changeLoginBg"){//更改登录背景图片
			$("#loginBackgroundPicPath").attr("src",path);
			loginBackgroundPicPath = fileName;
		}else if(busiType=="changeLoginKuang"){//更改登录框背景图片
			$("#loginKuangPicPath").attr("src",path);
			loginKuangPicPath = fileName;
		}else if(busiType=="changeBottomPic"){//更改底部栏背景图片
			$("#bottomPicPath").attr("src",path);
			bottomPicPath = fileName;
		}else if(busiType=="changeLogoPic"){//更改主页logo图片
			$("#mainLogoPicPath").attr("src",path);
			mainLogoPicPath = fileName;
		}else if(busiType=="addCustomerPic"){//添加底部栏左侧客户信息图片
			addCustomerPic(dataArr);
		}else if(busiType=="addCompanyPic"){//添加底部栏右侧客户信息图片
			addCompanyPic(dataArr);
		}
	}
}

//删除底部栏背景图片
function deleteBottomPic(){
	top.layer.open({
		title:'信息',
		closeBtn :0,
		icon: 3,
		area:[250,150],
		btn:['确定', '取消'],
		content:'确定要删除底部栏背景图片吗',
		yes: function(index){
			bottomPicPath = "";
			$("#bottomPicPath").attr("src",bottomPicPath);
			top.layer.close(index);
	    }
	});
}

//绑定系统信息配置下的添加按钮事件
function bindAddBtnEvent(){
	$("#addCusText").click(function(){
		addCustomerText('');
	});
	$("#addCusPic").click(function(){
		openUploadPicWindow("addCustomerPic");
	});
	$("#addComText").click(function(){
		addCompanyText('');
	});
	$("#addComPic").click(function(){
		openUploadPicWindow("addCompanyPic");
	});
}

//底部栏左侧客户信息--添加文本框
function addCustomerText(text){
	var html = '<div class="single_info_div"><textarea>'+text+'</textarea></div>';
	if($("#empty_customer_info").length > 0){
		$("#empty_customer_info").before(html);
	}else{
		html += '<div class="empty_btn_div" id="empty_customer_info"><button onclick="emptyCustomerInfo()" class="btn-basic btn-delete"><i class="btn-icon delete-icon"></i>清空</button></div>';
		$("#customerInfoDiv").append(html);
	}
}
//底部栏左侧客户信息--添加图片
function addCustomerPic(dataArr){
	var html = "";
	for(var i=0;i<dataArr.length;i++){
		var fileName = dataArr[i].fileID+"."+dataArr[i].compressFileID;
		var path = top.contextPath+"/core/style/commonimages/"+fileName;
		html += '<div class="single_info_div"><img src="'+path+'" name-data="'+fileName+'"/></div>';
	}
	if($("#empty_customer_info").length > 0){
		$("#empty_customer_info").before(html);
	}else{
		html += '<div class="empty_btn_div" id="empty_customer_info"><button onclick="emptyCustomerInfo()" class="btn-basic btn-delete"><i class="btn-icon delete-icon"></i>清空</button></div>';
		$("#customerInfoDiv").append(html);
	}
}
//清空底部栏左侧客户信息
function emptyCustomerInfo(){
	top.layer.open({
		title:'信息',
		closeBtn :0,
		icon: 3,
		area:[250,150],
		btn:['确定', '取消'],
		content:'确定要清空底部栏左侧客户信息吗',
		yes: function(index){
			$("#customerInfoDiv").empty();
			top.layer.close(index);
	    }
	});
}

//底部栏右侧公司信息--添加文本框
function addCompanyText(text){
	var html = '<div class="single_info_div"><textarea>'+text+'</textarea></div>';
	if($("#empty_company_info").length > 0){
		$("#empty_company_info").before(html);
	}else{
		html += '<div class="empty_btn_div" id="empty_company_info"><button onclick="emptyCompanyInfo()" class="btn-basic btn-delete"><i class="btn-icon delete-icon"></i>清空</button></div>';
		$("#companyInfoDiv").append(html);
	}
}
//底部栏右侧公司信息--添加图片
function addCompanyPic(dataArr){
	var html = "";
	for(var i=0;i<dataArr.length;i++){
		var fileName = dataArr[i].fileID+"."+dataArr[i].compressFileID;
		var path = top.contextPath+"/core/style/commonimages/"+fileName;
		html += '<div class="single_info_div"><img src="'+path+'" name-data="'+fileName+'"/></div>';
	}
	if($("#empty_company_info").length > 0){
		$("#empty_company_info").before(html);
	}else{
		html += '<div class="empty_btn_div" id="empty_company_info"><button onclick="emptyCompanyInfo()" class="btn-basic btn-delete"><i class="btn-icon delete-icon"></i>清空</button></div>';
		$("#companyInfoDiv").append(html);
	}
}
//清空底部栏右侧公司信息
function emptyCompanyInfo(){
	top.layer.open({
		title:'信息',
		closeBtn :0,
		icon: 3,
		area:[250,150],
		btn:['确定', '取消'],
		content:'确定要清空底部公司信息吗',
		yes: function(index){
			$("#companyInfoDiv").empty();
			top.layer.close(index);
	    }
	});
}

//提示是否刷新单位树缓存数据
function refreshOrgCacheTree(){
	top.layer.open({
		title:'信息',
		closeBtn :0,
		icon: 3,
		area:[250,150],
		btn:['确定', '取消'],
		content:'确定要刷新6.X系统的单位树缓存数据吗',
		yes: function(index){
			top.layer.close(index);
			refreshOrgCacheTreeService();
	    }
	});
}

function refreshOrgCacheTreeService() {
	$('body').addLoading({msg:'正在刷新单位树缓存数据，请等待...'});
	Ajax.service(
		'OrgService',
		'refresh', 
	    [1,'001',true],
	    function(data){
			$("body").removeLoading();
			top.layer.alert("单位树缓存刷新成功",{closeBtn :0,icon:1}); 
	    }
	); 		  
}


//提示是否刷新资产barcode缓存数据
function refreshBarCodeCacheTree(){
	top.layer.open({
		title:'信息',
		closeBtn :0,
		icon: 3,
		area:[450,180],
		btn:['确定', '取消'],
		content:'确定要刷新6.X系统资产的BarCode（非AssetRegBarCode）字段的缓存数据吗？注意要挑选没什么单位操作数据的时候进行刷新！',
		yes: function(index){
			top.layer.close(index);
			refreshBarCodeCacheTreeService();
	    }
	});
}

function refreshBarCodeCacheTreeService() {
	$('body').addLoading({msg:'正在刷新资产的BarCode缓存数据，请等待...'});
	Ajax.service(
		'BusinBillNoFactoryService',
		'refershBarCode', 
	    [],
	    function(data){
			$("body").removeLoading();
			top.layer.alert("BarCode缓存数据刷新成功",{closeBtn :0,icon:1}); 
	    }
	); 		  
}

//提示是否刷新系统版本号
function refreshProgramVersion(){
	top.layer.open({
		title:'信息',
		closeBtn :0,
		icon: 3,
		area:[250,150],
		btn:['确定', '取消'],
		content:'确定要刷新系统的版本号数据吗',
		yes: function(index){
			top.layer.close(index);
			reloadProgramVersion();
	    }
	});
}

function reloadProgramVersion() {
	$('body').addLoading({msg:'正在刷新系统版本号数据，请等待...'});
	Ajax.service(
		'SystemConfigService',
		'reloadProgramVersion', 
	    [],
	    function(data){
			$("body").removeLoading();
			top.layer.alert("系统版本号刷新成功",{closeBtn :0,icon:1}); 
	    }
	); 		  
}


function reloadProgramVersion() {
    $('body').addLoading({msg:'正在刷新系统版本号数据，请等待...'});
    Ajax.service(
        'SystemConfigService',
        'reloadProgramVersion',
        [],
        function(data){
            $("body").removeLoading();
            top.layer.alert("系统版本号刷新成功",{closeBtn :0,icon:1});
        }
    );
}

function reloadDockerAchieveProperties(){
    $('#div_dockers').addLoading({msg:'正在刷新，请等待...'});
    Ajax.service('SysLevelParamBO','reloadDockerAchieveProperties',[],function(data){
        dockers = data;
        loadDockers();
        $('#div_dockers').removeLoading();
    });
}
function configureDockerAchieveParam(dockerId,dockerAchieveId, paramName, paramValue, callback){
    $('#div_dockers').addLoading({msg:'正在修改，请等待...'});
    Ajax.service('SysLevelParamBO','configureDockerAchieveParam',[dockerId, dockerAchieveId, paramName, paramValue],function(data){
        if(data){
            top.layer.msg('修改成功！', {time:1000});
            if(callback)callback(data);
        }else{
            top.layer.alert('修改失败！',{closeBtn :2,icon:5});
        }
        $('#div_dockers').removeLoading();
    });
}

function configureDocker(dockerId, dockerAchieveId, callback){
    $('#div_dockers').addLoading({msg:'正在切换，请等待...'});
    Ajax.service('SysLevelParamBO','useDockerAchieve',[dockerId, dockerAchieveId],function(data){
        if(data){
            top.layer.msg('切换成功！', {time:1000});
            if(callback)callback(data);
        }else{
            top.layer.alert('切换失败！',{closeBtn :2,icon:5});
        }
        $('#div_dockers').removeLoading();
    });
}

function loadDockers(){
    if(dockers){
        var target = $('#div_dockers');
        var getAchieveHtml = function(_dockerId, name, description){
            return "<div class='configrow2'>" +
                "<label>"+name+":</label>" +
                "<label>"+description+"</label>" +
                " <br/>" +
                "<input type='text' id='"+_dockerId+"' class='easyui-combobox '/>" +
                "<br/>" +
                "<label id='lb_achieve_"+_dockerId+"'></label>" +
                "<ul id='ul_achieve_"+_dockerId+"'></ul>" +
                "</div>";
        };
        var showAchieveDetail = function(_dockerId, description, params){
            $('#lb_achieve_'+_dockerId).html(description||"");
            $('#ul_achieve_'+_dockerId).html("");
            if(params){
                var clickSureInput = function(){
                    var that = this;
                    var value = $(that).html();
                    var previous = $(that).prev();
                    if(value == '修改'){
                        $(that).html('确定');
                        previous.removeClass('disableText');
                        previous.removeAttr('readonly');
                    }else{
                        var _paramValueId = $(previous).attr('id');
                        var temp = _paramValueId.split("_params_");

                        var _dockerId = temp[0];
                        var dockerId = underline2Dot(_dockerId);
                        var dockerAchieveId = $('#'+_dockerId).combobox('getValue');
                        var paramName = temp[1];
                        var paramValue = previous.val();
                        configureDockerAchieveParam(dockerId, dockerAchieveId, paramName, paramValue, function(data){
                            $(that).html('修改');
                            previous.addClass('disableText');
                            previous.attr('readonly', 'readonly');
                        });
                    }
                };
                $.each(params,function(i,v){
                    var li_html="<li>"+v.name+"：<input type='text' id='"+_dockerId+"_params_"+v.name+"' value='"+v.value+"' class='disableText' readonly='readonly' style='width:400px;'/><button id='"+_dockerId+"_params_"+v.name+"_sure' class='btn-basic btn-sure'>修改</button>"+v.description+"</li>";
                    $('#ul_achieve_'+_dockerId).append(li_html);
                    $("#"+_dockerId+"_params_"+v.name+"_sure").click(clickSureInput);
                });
            }
        };

        var changeAchieve = function(newValue, oldValue){
            var that = this;
            var _dockerId = that.id;
            var dockerId = underline2Dot(_dockerId);
            var dockerAchieveId = newValue || '';
            configureDocker(dockerId, dockerAchieveId,function(data){
                showAchieveDetail(_dockerId, data.description, data.paramVOList);
            });
        };

        $.each(dockers, function(i,v){
            var dockAchieves = v.dockerAchieveVOList || [];
            var currentDockerAchieve = v.currentDockerAchieveVO|| {id:''};
            var _dockerId = dot2Underline(v.id);
            target.append(getAchieveHtml(_dockerId, v.name, v.description));
            var achieveTarget = $('#'+_dockerId);
            achieveTarget.combobox({
                height:'auto',
                width:'auto',
                valueField:'id',
                textField:'name',
                value:currentDockerAchieve.id,
                data:dockAchieves,
                onChange: changeAchieve
            });
            if(currentDockerAchieve.id){
                showAchieveDetail(_dockerId, currentDockerAchieve.description, currentDockerAchieve.paramVOList);
            }
        });
    }
}

function dot2Underline(value){
    return value.split('.').join('_');
}

function underline2Dot(id){
    return id.split('_').join('.');
}
